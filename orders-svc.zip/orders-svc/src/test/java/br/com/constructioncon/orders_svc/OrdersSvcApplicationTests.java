package br.com.constructioncon.orders_svc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdersSvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
