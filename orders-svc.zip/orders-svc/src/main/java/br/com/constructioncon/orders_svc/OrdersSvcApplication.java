package br.com.constructioncon.orders_svc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrdersSvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrdersSvcApplication.class, args);
	}

}
